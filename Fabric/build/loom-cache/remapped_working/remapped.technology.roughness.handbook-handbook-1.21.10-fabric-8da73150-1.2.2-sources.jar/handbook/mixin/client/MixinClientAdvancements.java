package handbook.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import handbook.client.base.ClientAdvancements;
import net.minecraft.network.protocol.game.ClientboundUpdateAdvancementsPacket;

@Mixin(net.minecraft.client.multiplayer.ClientAdvancements.class)
public abstract class MixinClientAdvancements {

    @Inject(at = @At("RETURN"), method = "update")
    public void handbook$onSync(ClientboundUpdateAdvancementsPacket packet, CallbackInfo info) {
        ClientAdvancements.onClientPacket();
    }

}
