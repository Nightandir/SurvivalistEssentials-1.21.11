package handbook.client.book.gui.button;

import handbook.client.book.gui.GuiBook;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class GuiButtonBookConfig extends GuiButtonBook {

	public GuiButtonBookConfig(GuiBook parent, int x, int y, Button.OnPress onPress) {
		super(parent, x, y, 308, 20, 11, 11, onPress,
				Component.translatable("handbook.gui.lexicon.button.config"));
	}

}
