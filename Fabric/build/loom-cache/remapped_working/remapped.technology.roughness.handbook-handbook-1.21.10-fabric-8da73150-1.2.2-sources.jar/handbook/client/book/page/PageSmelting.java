package handbook.client.book.page;

import handbook.client.book.page.abstr.PageSimpleProcessingRecipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SmeltingRecipe;

public class PageSmelting extends PageSimpleProcessingRecipe<SmeltingRecipe> {

    public PageSmelting() {
        super(RecipeType.SMELTING);
    }

}
