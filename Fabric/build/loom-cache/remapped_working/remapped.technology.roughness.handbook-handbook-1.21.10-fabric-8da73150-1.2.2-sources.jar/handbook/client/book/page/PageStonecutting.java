package handbook.client.book.page;

import handbook.client.book.page.abstr.PageSimpleProcessingRecipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.StonecutterRecipe;

public class PageStonecutting extends PageSimpleProcessingRecipe<StonecutterRecipe> {

    public PageStonecutting() {
        super(RecipeType.STONECUTTING);
    }

}
