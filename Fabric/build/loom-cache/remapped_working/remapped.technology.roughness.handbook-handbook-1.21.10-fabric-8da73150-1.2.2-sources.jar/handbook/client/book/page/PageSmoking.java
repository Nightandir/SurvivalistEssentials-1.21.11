package handbook.client.book.page;

import handbook.client.book.page.abstr.PageSimpleProcessingRecipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SmokingRecipe;

public class PageSmoking extends PageSimpleProcessingRecipe<SmokingRecipe> {

    public PageSmoking() {
        super(RecipeType.SMOKING);
    }

}
