package handbook.client.book.page;

import handbook.client.book.page.abstr.PageSimpleProcessingRecipe;
import net.minecraft.world.item.crafting.BlastingRecipe;
import net.minecraft.world.item.crafting.RecipeType;

public class PageBlasting extends PageSimpleProcessingRecipe<BlastingRecipe> {

    public PageBlasting() {
        super(RecipeType.BLASTING);
    }

}
