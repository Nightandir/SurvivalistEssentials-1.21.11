package handbook.client.book.page;

import com.google.gson.annotations.SerializedName;
import handbook.client.book.BookPage;
import handbook.client.book.gui.GuiBook;
import net.minecraft.client.gui.GuiGraphics;

public class PageEmpty extends BookPage {

    @SerializedName("draw_filler") boolean filler = true;

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        if (filler) {
            GuiBook.drawPageFiller(guiGraphics, book, 0, 0);
        }
    }

}
