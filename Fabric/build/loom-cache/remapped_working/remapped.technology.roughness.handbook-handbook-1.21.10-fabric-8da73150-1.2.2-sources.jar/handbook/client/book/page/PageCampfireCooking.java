package handbook.client.book.page;

import handbook.client.book.page.abstr.PageSimpleProcessingRecipe;
import net.minecraft.world.item.crafting.CampfireCookingRecipe;
import net.minecraft.world.item.crafting.RecipeType;

public class PageCampfireCooking extends PageSimpleProcessingRecipe<CampfireCookingRecipe> {

    public PageCampfireCooking() {
        super(RecipeType.CAMPFIRE_COOKING);
    }

}
