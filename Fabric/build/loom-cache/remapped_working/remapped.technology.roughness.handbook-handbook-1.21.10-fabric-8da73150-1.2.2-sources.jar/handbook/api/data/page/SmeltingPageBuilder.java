package handbook.api.data.page;

import handbook.api.data.EntryBuilder;
import net.minecraft.resources.ResourceLocation;

public class SmeltingPageBuilder extends RecipePageBuilder<SmeltingPageBuilder> {

    public SmeltingPageBuilder(ResourceLocation recipe, EntryBuilder entryBuilder) {
        super("handbook:smelting", recipe, entryBuilder);
    }

}
