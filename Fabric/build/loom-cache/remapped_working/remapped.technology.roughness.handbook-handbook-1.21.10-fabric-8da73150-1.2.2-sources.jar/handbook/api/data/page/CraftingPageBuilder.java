package handbook.api.data.page;

import handbook.api.data.EntryBuilder;
import net.minecraft.resources.ResourceLocation;

public class CraftingPageBuilder extends RecipePageBuilder<CraftingPageBuilder> {

    public CraftingPageBuilder(ResourceLocation recipe, EntryBuilder entryBuilder) {
        super("handbook:crafting", recipe, entryBuilder);
    }

}
