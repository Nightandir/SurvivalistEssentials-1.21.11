package handbook.api.data.page;

import handbook.api.data.EntryBuilder;
import net.minecraft.resources.ResourceLocation;

public class SmokingPageBuilder extends RecipePageBuilder<SmokingPageBuilder> {

    public SmokingPageBuilder(ResourceLocation recipe, EntryBuilder entryBuilder) {
        super("handbook:smoking", recipe, entryBuilder);
    }

}
