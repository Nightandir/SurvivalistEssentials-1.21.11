package handbook.api.data.page;

import handbook.api.data.EntryBuilder;
import net.minecraft.resources.ResourceLocation;

public class StonecuttingPageBuilder extends RecipePageBuilder<StonecuttingPageBuilder> {

    public StonecuttingPageBuilder(ResourceLocation recipe, EntryBuilder entryBuilder) {
        super("handbook:stonecutting", recipe, entryBuilder);
    }

}
