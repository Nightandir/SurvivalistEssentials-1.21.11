package handbook.api.data.page;

import handbook.api.data.EntryBuilder;
import net.minecraft.resources.ResourceLocation;

public class SmithingPageBuilder extends RecipePageBuilder<SmithingPageBuilder> {

    public SmithingPageBuilder(ResourceLocation recipe, EntryBuilder entryBuilder) {
        super("handbook:smithing", recipe, entryBuilder);
    }

}
