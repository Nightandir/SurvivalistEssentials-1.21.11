package handbook.api.data.page;

import handbook.api.data.EntryBuilder;
import net.minecraft.resources.ResourceLocation;

public class CampfirePageBuilder extends RecipePageBuilder<CampfirePageBuilder> {

    public CampfirePageBuilder(ResourceLocation recipe, EntryBuilder entryBuilder) {
        super("handbook:campfire", recipe, entryBuilder);
    }

}
