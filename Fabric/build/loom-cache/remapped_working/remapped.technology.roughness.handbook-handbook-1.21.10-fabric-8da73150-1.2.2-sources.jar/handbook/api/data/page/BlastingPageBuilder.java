package handbook.api.data.page;

import handbook.api.data.EntryBuilder;
import net.minecraft.resources.ResourceLocation;

public class BlastingPageBuilder extends RecipePageBuilder<BlastingPageBuilder> {

    public BlastingPageBuilder(ResourceLocation recipe, EntryBuilder entryBuilder) {
        super("handbook:blasting", recipe, entryBuilder);
    }

}
