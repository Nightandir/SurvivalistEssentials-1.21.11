@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.recipe.types;

import javax.annotation.ParametersAreNonnullByDefault;
