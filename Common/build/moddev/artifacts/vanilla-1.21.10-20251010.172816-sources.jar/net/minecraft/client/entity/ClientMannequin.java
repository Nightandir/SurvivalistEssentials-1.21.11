package net.minecraft.client.entity;

import com.mojang.logging.LogUtils;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import javax.annotation.Nullable;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.PlayerSkinRenderCache;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Parrot;
import net.minecraft.world.entity.decoration.Mannequin;
import net.minecraft.world.entity.player.PlayerSkin;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class ClientMannequin extends Mannequin implements ClientAvatarEntity {
    private static final Logger LOGGER = LogUtils.getLogger();
    public static final PlayerSkin DEFAULT_SKIN = DefaultPlayerSkin.get(Mannequin.DEFAULT_PROFILE.partialProfile());
    private final ClientAvatarState avatarState = new ClientAvatarState();
    @Nullable
    private CompletableFuture<Optional<PlayerSkin>> skinLookup;
    private PlayerSkin skin = DEFAULT_SKIN;
    private final PlayerSkinRenderCache skinRenderCache;

    public static void registerOverrides(PlayerSkinRenderCache playerSkinRenderCache) {
        Mannequin.constructor = (p_448683_, p_448684_) -> (Mannequin)(p_448684_ instanceof ClientLevel
            ? new ClientMannequin(p_448684_, playerSkinRenderCache)
            : new Mannequin(p_448683_, p_448684_));
    }

    public ClientMannequin(Level level, PlayerSkinRenderCache playerSkinRenderCache) {
        super(level);
        this.skinRenderCache = playerSkinRenderCache;
    }

    @Override
    public void tick() {
        super.tick();
        this.avatarState.tick(this.position(), this.getDeltaMovement());
        if (this.skinLookup != null && this.skinLookup.isDone()) {
            try {
                this.skinLookup.get().ifPresent(this::setSkin);
                this.skinLookup = null;
            } catch (Exception exception) {
                LOGGER.error("Error when trying to look up skin", (Throwable)exception);
            }
        }
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> p_446830_) {
        super.onSyncedDataUpdated(p_446830_);
        if (p_446830_.equals(DATA_PROFILE)) {
            this.updateSkin();
        }
    }

    private void updateSkin() {
        if (this.skinLookup != null) {
            CompletableFuture<Optional<PlayerSkin>> completablefuture = this.skinLookup;
            this.skinLookup = null;
            completablefuture.cancel(false);
        }

        this.skinLookup = this.skinRenderCache.lookup(this.getProfile()).thenApply(p_445932_ -> p_445932_.map(PlayerSkinRenderCache.RenderInfo::playerSkin));
    }

    @Override
    public ClientAvatarState avatarState() {
        return this.avatarState;
    }

    @Override
    public PlayerSkin getSkin() {
        return this.skin;
    }

    private void setSkin(PlayerSkin skin) {
        this.skin = skin;
    }

    @Nullable
    @Override
    public Component belowNameDisplay() {
        return this.getDescription();
    }

    @Nullable
    @Override
    public Parrot.Variant getParrotVariantOnShoulder(boolean p_446133_) {
        return null;
    }

    @Override
    public boolean showExtraEars() {
        return false;
    }
}
